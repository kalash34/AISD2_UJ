#pragma once
#include<iostream>
#include <vector>
#include <algorithm>

using namespace std;

class setList
{

public:

    std::vector<int> vec;

    int getSize();
    void printSet();
    void add(int x);
    void withdraw(int x);
    bool isInSet(int x);
    setList operator+(setList& otherSet){

        setList unionSet; 		//zbior wynikowy
	int it=vec.size();
        for (int i = 0; i <= it; i++){
            unionSet.add(vec[i]);
        }
	it = otherSet.getSize();
        for (int j = 0; j <= it;j++){

            unionSet.add(otherSet.vec[j]);


        }

        //zwracamy zbior po zsumowaniu dwoch zbiorow
        return unionSet;




    }
    setList operator*(setList& otherSet){

        setList sumSet; //zbior wynikowy
	int it = vec.size();
        for (int i = 0; i <= it; i++){
             if (std::count(vec.begin(), vec.end(), i) && otherSet.isInSet(vec[i])) {   // Jesli jest w obydwu zbiorach dodaj
                sumSet.add(vec[i]);
        }

        }

        //zwracamy zbior po iloczynie dwoch zbiorow ( czyli czesc wspolna dwoch zbiorow)
        return sumSet;



    }
    setList operator-(setList& otherSet){

        // podzielony zbior
        setList substracted;
        //iterujemy po drugim zbiorze i wyjmujemy elementy
	int it = vec.size();
        for(int i =0;i <= it;i++){
            if(!otherSet.isInSet(vec[i])){
                if(!otherSet.isInSet(vec[i])){
                    substracted.add(vec[i]);
                }
            }

        }

        return substracted;
    }


    bool operator==(setList& otherSet){

        bool isEqual = false;

        if (std::includes(vec.begin(), vec.end(),
                    otherSet.vec.begin(), otherSet.vec.end())){
                         isEqual = true;
        }

        return isEqual;
    }

    bool operator<=(setList& otherSet){
	int len1=vec.size();
	int len2=otherSet.getSize();

        if(len1 <= len2){
            return true;

        }
        return false;

    }
    setList() {
    }


};

int setList::getSize() {
    return vec.size();    //uzywamy metody stl'a do otrzymania rozmiaru
}



void setList::withdraw(int x){

std::vector<int>::iterator position = std::find(vec.begin(), vec.end(), x); //okreslamy pozycje elementu w zbiorze
if (position != vec.end()){ // == myVector.end() oznacza ze elementu nie znaleziono
    vec.erase(position);   // jezeli znaleziono indeks tego elementu w zbiorze to usuwamy
}



}



bool setList::isInSet(int d) {
    int success = false;
    int it = vec.size();
    for(int i = 0; i <= it; i++){
        if(vec[i] == d){
            success = true;
        }
    }

    return success;

}

void setList::add(int d){
    int success = true;
    int it = vec.size();
    if(it!=0){
    //Sprawdzamy Czy jest w zbiorze
    for(int i = 0; i <= it; i++){
        if(vec[i] == d){
            success = false;
        }
    }
    }
    if(success){
        vec.push_back(d);
    }


}



//Wypisujemy zawartosc zbioru

void setList::printSet(){
    cout<<"Zawartosc Zbioru(Power Set): "<<endl;
    cout<<" { " << endl;
    int it=vec.size();
    if(it != 0){

        for (int i = 0; i < it; ++i){
            cout << " { " << vec[i] << " } ";
        }
    }

    cout << " } " << endl;
}


