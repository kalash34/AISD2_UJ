#pragma once
#include <iostream>

using namespace std;

class setArr
{
int size;
const int universeSize = 100;
bool* table;
bool checkRangeCorrectness(int x);

public:
	setArr();
	void insert(int x);
	void withdraw(int x);
	bool isInSet(int i);
	int getSize();
	void clearSet();
	void printSet();

        setArr operator+(setArr& object){

		setArr unionSet; //zbior wynikowy

		for(int i=0; i< size; i++){
		
		unionSet.insert(i);
		
		}

		for (int j = 0; j <object.getSize(); j++){

		    unionSet.insert(j);


		}
		//zwracamy zbior po zsumowaniu dwoch zbiorow
		return unionSet;
    	}

    // Intersection Of Sets - Czesc Wspolna zbiorow

    setArr operator*(setArr& object){
           setArr intersection;
	   // indeksy te same wiec sprawdzamy dla jednego
           for (int i = 0; i <size; i++)
           {
              if (object.isInSet(i))
              {
                 intersection.insert(i);
              }

           }


           return intersection;


    }
    //Roznica Zbiorow

    setArr operator-(setArr& object){

        // podzielony zbior
        setArr substracted;
        for(int i =0;i < size;i++){
            if(this->isInSet(i)){
                if(!object.isInSet(i)){
                    substracted.insert(i);
                }
            }

        }

        return substracted;
    }


    bool operator==(setArr& object){
        bool isEqual = false;

        // Jesli rozmiar(s1) == rozmiar(s2)
        // oraz s1.jest_podzbiorem(s2) =>  zbiory sa identyczne


        if(size == object.getSize()){
          isEqual=true;   // bo elementy sa rowne indeksom, czyli naleza do naszego Uniwersum

    	}

    	return isEqual;

    }

    bool operator<=(setArr& object){

        if(size <= object.getSize()){
            return true;

        }
        return false;

    }

};



setArr::setArr() : size(0) {
    table = new bool[universeSize];	
    table[universeSize]={ 0 };


}

int setArr::getSize() {
    return size;    
}

bool setArr::checkRangeCorrectness(int x){

	if((x >= 0) && ( x< 99 )){
		return true;
	}
	return false;
}


bool setArr::isInSet(int i) {
    int success = false;
    if(this->checkRangeCorrectness(i)){
    if(table[i] == true){
            success = true;
    }
    }
    return success;
}

void setArr::clearSet(){
	
    table[universeSize] = {0};
    size=0;

}



void setArr::printSet(){

    cout<<" Zawartosc Zbioru(Power Set): "<<endl;
    cout<<" { " << endl;
    if(size != 0){

        for (int i = 0; i < size ; ++i){
	    	if(table[i]==true){
           	 cout << " { " << i << " } ";
            }
        }
    }

    cout << " } " << endl;
}


void setArr::insert(int x){
    if(!this->isInSet(x)){
        table[x] = true;
        size++;


    }
}
    

//usun element ze zbioru
void setArr::withdraw(int x){
   
    if(this->isInSet(x)){     
	table[x]=false;
	size--;
    }

}
