Tutaj poprawna implementacja zbioru tablicowego, na tablicy bool - >


ta poprzednia byla zla.s
