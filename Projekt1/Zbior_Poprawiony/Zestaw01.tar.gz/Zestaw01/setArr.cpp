
#include<iostream>
#include <vector>
#include <algorithm>
#include "setArr.h"
using namespace std;







bool isPrime(int n)
{
    if (n <= 1)
        return false;

    for (int i = 2; i < n; i++)
        if (n % i == 0)
            return false;

    return true;
}


int main(){
    
    setArr s1 = setArr();

    for (int i=0;i<100;i++){
        
    
        s1.insert(i);
        
    }
    
    vector<int> primes;
    for(int i=0;i<100;i++){
            if(isPrime(i)){
                primes.push_back(i);
            }

    }
    s1.printSet();
    setArr s2 = s1;

    for(int i=0;i<100;i++){
            int pom=primes[i];
            if(s1.isInSet(pom)){
            s1.withdraw(pom);
            }
    }



    cout<<"Po usunieciu liczb pierwszych: "<<endl;
    s1.printSet();


    cout<<"Przekroj Zbiorow = " <<endl;
    setArr s3 = s2 * s1;

    s1.printSet();



}
