#pragma once
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>
#include "edge.h"
/*
Zakladamy ze wierzcholki sa numerowane kolejnymi liczbami naturalnymi

*/


class Graf
{
    std::vector<std::vector<edge>> vertexList;


public:
    Graf();
    void createVertices(int ile);    
    void addEdge(int i_Vertex_Index_1, int i_Vertex_Index_2);    
    bool removeEdge(int i_Vertex_Index_1, int i_Vertex_Index_2);
    bool checkEdge(int i_Vertex_Index_1, int i_Vertex_Index_2);
    int vertexDegree(int idx); 
    std::vector<int> getNeighbourIndices(int idx);
    void printNeighbourIndices(int idx);
    int getNumberOfEdges();
    void readFromFile(std::string path); 
};




Graf::Graf(){
	

}

void Graf::createVertices(int ile){
	for(int i=0;i<ile;i++){
		vertexList[i][i];	//na liscie sasiedztwa, wierzcholki bez krawedzi sasiaduja tylko same ze soba
	}
	
	


}



void Graf::addEdge(int a, int b){
	//edge krawedz = edge(a, b);
	//edge krawedz2 = edge(b,a);	// Ale w sumie dodanie jednej mozna zrobic przez dwa push_backi
					// i dac na liscie sasiedztwa dwa inty- dla dwoch wierszy, ale pozo klasa edge w takim razie(?)
	//vrtexList[a].push_back(krawedz)
	//vertexList[b].push_back(krawedz)	// O(2)
	vertexList[a][b]=1;
	vertexList[b][a]=1;
}


bool Graf::removeEdge(int a, int b){
	edge krawedz = edge(a, b);
	if(std::find(vertexList.begin(), vertexList.end(), krawedz) != vertexList.end())){		
		vertexList.erase(edge(a,b));	// O(1)
	return true;
	}else{
		throw std::invalid_argument("Brak krawedzi dla tych indeksow! ");
	return false;	
	}


}
//Czy istnieje?
bool Graf::checkEdge(int a, int b){
	
	if(std::find(vertexList.begin(), vertexList.end(), krawedz) != vertexList.end())){
	return true;
	}else{
	return false;
	}
	

}

//
int Graf::vertexDegree(int idx){
//sprawdzamy ile krawedzi zawiera ten wierzcholek - stopien=liczba sasiadow
	int neighboursCount = vertexList[idx].size();
	int countDegree=0;	
	for(int i=0;i<vertexList.size();i++){
		countDegree++;	//dla kazdego stopnia zwiekszamy wierzcholek
	}	

	return countDegree;
}

//O(n)
std::vector<int> Graf::getNeighbourIndices(int idx){
	vector<int> indeksy_sasiadow;
	for(int i=0;i<vertexList[idx].size();i++){
		indeksy_sasiadow.push_back(i);
	}
	return indeksy_sasiadow;	//zwracamy wektor z sasiadami
}

//O(n)
void Graf::printNeighbourIndices(int idx){
	vector<int> indeksy = getNeighbourIndices(int idx);	//pobierami wektor z sasiadami wierzcholka
	cout<<"Indeksy sasiadow wierzcholka nr="<<idx<<" "<<endl;
	for(int i=0;i<indeksy.size();i++){
		cout<<" "<<indeksy[i]<<" ";
	}
	cout<<endl;
}

//Aby obliczyc liczbe krawedzi skorzystamy z
//
// Dla kazdego v c- V [ SUMA{ deg(v) } ]== 2 |E|

// wiec dzielimy sume stopni wszystkich wierzcholkow przez 2

// zlozonosc to wiec O( V )
int Graf::getNumberOfEdges(){
	int sum_degrees=0;
	for(int i=0;i<vertexList.size();i++){
	sum += vertexList[i].size();
	}
	return sum/2 ;
	
}

// zakladamy ze podany graf w pliku to ciag wierszami krawedzi (wierzcholek1 wierzcholek2 waga)

// to samo pytanie:
// https://www.cplusplus.com/forum/beginner/270567/
void Graf::readFromFile(string path){
	istream &in;
	int nedge, a, b, cost;
	int numVert;
	vector<int> adj = vector<vector<int> >( numVert, vector<int>( numVert, 0) );
	for ( int i = 0; i < nedge;i++){
		in >> a >> b >>cost;
		adj[a-1][b-1] = cost;
		//    adj[b-1][a-1] = cost; // dodajemy w obie strony dla grafy nieskierowanego
		
	}

}





void Graf::write( ostream &out )
{
   for ( int i = 0; i < numVert; i++ )
   {
      for ( int j = 0; j < numVert; j++ ) out << setw( 2 ) << adj[i][j] << ' ';
      out << '\n';
   }
}













