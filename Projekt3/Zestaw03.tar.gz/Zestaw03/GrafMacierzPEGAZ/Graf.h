#pragma once
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>
#include "edge.h"

using namespace std;
class Graf
{
    // musimy zalozyc maksymalna liczbe wierzcholkow
    // dlatego ta reprezentacja jest tak obszerna pamieciowo
    int matrix[100][100];	// zlozonosc pamieciowa dla zaledwie 100 wierzcholkow to nietrudno zauwazyc O (100 * 100)
    int numberOfVertices;

public:
    Graf();
    void createVertices(int ile);    
    void addEdge(int i_Vertex_Index_1, int i_Vertex_Index_2);    
    void removeEdge(int i_Vertex_Index_1, int i_Vertex_Index_2);
    bool checkEdge(int i_Vertex_Index_1, int i_Vertex_Index_2);
    int vertexDegree(int idx); 
    std::vector<int> getNeighbourIndices(int idx);
    void printNeighbourIndices(int idx);
    int getNumberOfEdges();

    void readFromFile(std::string path); 

private:
    void clear();
};

Graf::Graf(){
	for(int i=0;i<100;i++){
		for(int j=0;j<100;j++){
		matrix[i][j]=0;
		}	
	
	}
	numberOfVertices=100;	//ilosc wierzcholkow przyjeta z gory

}

// O( ile )
void Graf::createVertices(int ile){
	//zakladamy ze resetujemy graf
	if(ile > 0 && ile < numberOfVertices){
		for(int i=0;i<ile;i++){
			matrix[i][i]=1;	//w macierzy bez krawedzi wierzcholki sasiaduja tylko ze soba
		}
	}else{
		throw invalid_argument("Niepoprawna liczba wierzcholkow! ");
	}

}

// O(2)
void Graf::addEdge(int a, int b){
	if((a>0 && a<100) && (b > 0 && b < 100)){
	matrix[a][b]=1;
	matrix[b][a]=1;	        // w tej reprezentacji graf jest nieskierowany ( uzupelniamy indeksy w obydie strony )
	}			// zlozonosc O(2)
	else{
		throw invalid_argument("Niepoprawne indeksy wierzcholkow! ");
	}
	
}

// O(2)
void Graf::removeEdge(int a, int b){
	if((a>0 && a<100) && (b > 0 && b < 100)){
	matrix[a][b]=0;
	matrix[b][a]=0;	        
	}			// zlozonosc O(2)
	else{
		throw invalid_argument("Niepoprawne indeksy wierzcholkow! ");
	}


}

int Graf::vertexDegree(int idx){
	int countDegree=0;
	if((idx>0 && idx<100)){
	
	for(int i=0;i<100;i++){
		if(matrix[idx][i]==1){	//sprawdzamy liczbe sasiadow dla danego indeksu wierzcholka
		countDegree++;
		}

	}

	else{
		
		throw invalid_argument("Niepoprawne indeksy wierzcholkow! ");
	}
	return countDegree;
}


vector<int> Graf::getNeighbourIndices(int idx){
	
}






